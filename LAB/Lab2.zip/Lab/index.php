<?php
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $first= $_POST['Firstname'];
        $last=$_POST['Lastname'];
        $gender=$_POST['Gender'];
        $comment=$_POST['comment'];
        
        $array=array($first, $last, $gender, $comment);
     
        file_put_contents('temp.txt', $first.','.$last. ',' .$gender.','.$comment.'\n');
        
    }
    
    switch($gender){
        case 'Male': 
            echo 'Mr. '.$first.' '.$last."<br/>";
        
        case 'Female':
            echo 'Ms. '.$first.' '.$last."<br/>";
            
    }
    
    function getFirst(){
        $data = file_get_contents('temp.txt');
        $pieces = explode(',', $data);
        echo htmlspecialchars($pieces[0]);
    }
    
    function getLast(){
        $data = file_get_contents('temp.txt');
        $pieces = explode(',', $data);
        echo htmlspecialchars($pieces[1]);
    }
    
    function getComment(){
        $data = file_get_contents('temp.txt');
        echo htmlspecialchars($pieces[3]);
    }
    
    function getGender(){
        $data = file_get_contents('temp.txt');
        echo htmlspecialchars($pieces[2]);
    }
    
    function peoplePlacer(){
        $data = file_get_contents('temp.txt');
        echo htmlspecialchars($pieces[2]);
    }
?>