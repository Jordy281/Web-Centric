<?php
    $pageTitle = 'The website';
    
    //header('Location: View.php');
    include "User.php";
    $Users = array();
    
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $firstName=strip_tags($_POST['firstName']);
        $lastName=strip_tags($_POST['lastName']);
        $email=$_POST['email'];
        $password=strip_tags($_POST['password']);
        $confirmationPassword=strip_tags($_POST['confirmPassword']);
        passwordChecker($password,$confirmationPassword);
        $streetAddress=strip_tags($_POST['streetAddress']);
        $postalCode=strip_tags($_POST['postalCode']);
        $DOB=strip_tags($_POST['DOB']);
        $gender=$_POST['Gender'];
        
        $newUser= new User($firstName,$lastName, $email, $password,$confirmationPassword,$streetAddress,$postalCode,$DOB,$gender);
        $Users = array_push($Users,$newUser);
        $newUser->printInfo();
        
        echo "<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/Am4oKAmc2To?rel=0&autoplay=1\" frameborder=\"0\" allowfullscreen></iframe>";
        
    }
    
    function passwordChecker($p1,$p2){
        if (strcmp($p1,$p2)!=0){
            exit("Passwords dont match, Goodbye");
        }
    };
?>