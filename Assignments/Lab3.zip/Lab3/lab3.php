<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Whats Your Name?</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
</head>

<body>
	<div class= "container-fluid">
		<div class = "row" id ="header">
			<div class="col-sm-2">
				<h1>:)</h1>
			</div>
			<div class="col-sm-8">
				<div class="row">
					<?php
						include 'header.php';
						foreach($headervalues as $info){
							echo "<div class=\"col-sm-3\">";
							echo "<a href=$info[1]>$info[0]</a>";
							echo "</div>";
						}
					?>
				</div>
				
			</div>
			<div class="col-sm-2"></div>
		</div>
		<div class="container-fluid">
			<div class = "row" id = "theContent">
				<div id = "left-ish" class="col-sm-4">
					<form role ="form"  action= "PostUp.php" method = "POST">
					
						<div class = "form-group">
							<label for="fn">First Name:</label>
							<input type="text" class="form-control" id="fn" name="firstName" placeholder="John" required pattern="John">
						</div>
						
						<div class = "form-group">
							<label for="fn">Last Name:</label>
							<input type="text" class="form-control" id="ln" name="lastName" placeholder="Cena" required pattern="Cena">
						</div>
					   
						<div class="form-group">
							<label for="em">Email:</label>
							<input type="email"	class="form-control" id="em" name="email">
						</div>
						
						<div class="form-group">
							<label for="pwd">Password:</label>
							<input type="password" class="form-control" id="pwd" name="password" placeholder="Type Here!" required>
						</div>
						
						<div class="form-group">
							<label for="cpwd">Confirm Password:</label>
							<input type="password" class="form-control" id="cpwd" name="confirmPassword" placeholder="Type Here!" required>
						</div>
							
						<div class="form-group">
							<label for="SA">Street Address:</label>
							<input type="text"	class="form-control" id="SA" name="streetAddress">
						</div>
						
						<div class="form-group">
							<label for="pc">Postal Code:</label>
							<input type="text" class="form-control" id="pc" name="postalCode" pattern="[A-Z][a-z]+[0-9]+[A-Z][a-z]+ +[0-9]+[A-Z][a-z]+[0-9]" title="Ex. A1A 1A1">
						</div>
							
						<div class="form-group">
							<label for="thedate">Date of Birth (yyyy-mm-dd):</label>
							<input type="date" class="form-control" id="thedate" name="DOB"/>
						</div>
						
						<div class="form-group">
							<label for="name">Gender:</label>
							<select name="Gender" class = "form-control">
								<option value='Male'>Male</option>
								<option value='Female'>Female</option>
							</select>
						</div>
						
						<div class = "form-group">
							<button type = "submit" class = "btn btn-default">Sign in</button>
						</div>
					</form>
				</div>
				
				<div id ="right-ish" class="col-sm-8">
					<div class="row">
						<div id="col-sm-12">
							<iframe width="420" height="315" src="https://www.youtube.com/embed/ZfRr1Rcu5fw?rel=0&autoplay=1" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
					<div class="row">
						<div id="col-sm-12">
							<p>
								Just kidding, yes it does.
							</p>
							<p>
								To submit the form the user name must be:
								<ol>
									<li>A Pro Wrestler</li>
									<li>John Cena</li>
								</ol>
							</p>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</body>
</html>

	