<?php
    $pageTitle= "Hello World";
    //Each link will contain a link name and an address
    // For the purpose of this exercise, we will use a blank address
    
    $link1 = array("Link1", '');
    $link2 = array("Link2", '');
    $link3 = array("Link3", '');
    $link4 = array("Link4", '');
    $link5 = array("Link5", '');
    
    //put all information into an array    
    $headervalues = array($link1,$link2,$link3,$link4);
?>