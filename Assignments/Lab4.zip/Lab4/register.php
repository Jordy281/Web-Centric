<?php
    $pageTitle = 'The website';
    
    //header('Location: View.php');
    include "User.php";
    $Users = array();
    
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $firstName=strip_tags($_POST['firstName']);
        $lastName=strip_tags($_POST['lastName']);
        $email=$_POST['email'];
        $password=strip_tags($_POST['password']);
        $confirmationPassword=strip_tags($_POST['confirmPassword']);
        passwordChecker($password,$confirmationPassword);
        $streetAddress=strip_tags($_POST['streetAddress']);
        $postalCode=strip_tags($_POST['postalCode']);
        $DOB=strip_tags($_POST['DOB']);
        $gender=$_POST['Gender'];
        
        $newUser= new User($firstName,$lastName, $email, $password,$confirmationPassword,$streetAddress,$postalCode,$DOB,$gender);
        
        //echo "<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/Am4oKAmc2To?rel=0&autoplay=1\" frameborder=\"0\" allowfullscreen></iframe>";
        
        //connect to the database
        require_once('../mysqli_connect.php');
        $query = "INSERT INTO students(firstName, lastName, email, password, streetAddress, postalCode, DOB, gender) VALUES (NULL,?,?,?,?,?,?,?,?)";
        
        $stmt=mysqli_prepare($dbc, $query);
        
        mysqli_stmt_bind_param($stmt, "ssssssds", $firstName,$lastName,$email,$password, $streetAddress, $postalCode, $DOB, $gender);
        
        mysqli_stmt_execute($stmt);
        
        $affected_rows = mysqli_affected_rows($stmt);
        
        if($affected_rows==1){
            echo ' Student Entered';
            mysqli_stmt_close($stmt);
            mysqli_close($dbc);
        }else{
            echo 'ERROR OCCURED';
            mysqli_error();
            mysqli_stmt_close($stmt);
            mysqli_close($dbc);
        }
    }
    
    function passwordChecker($p1,$p2){
        if (strcmp($p1,$p2)!=0){
            exit("Passwords dont match, Goodbye");
        }
    };
?>