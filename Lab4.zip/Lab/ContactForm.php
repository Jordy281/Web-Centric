<?php
    class ContactForm{
        public $first="";
        public $last="";
        public $gender="";
        public function __construct($first,$last,$gender){
            $this->first=$first;
            $this->last=$class;
            $gender->gender=$gender;
        }
    }
?>