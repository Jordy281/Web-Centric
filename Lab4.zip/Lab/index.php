<?php

    include 'funcitons.php';
    
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $first= $_POST['Firstname'];
        $last=$_POST['Lastname'];
        $gender=$_POST['Gender'];
        $comment=$_POST['comment'];

        form_contact($first, $last, $gender, $comment);

        file_put_contents('temp1.txt', $first.','.$last. ',' .$gender.','.$comment.'\n');
        
        
    }
    
    $array = array(
        array("Parsa", "Sarshar", "Male", "comment 1", "img1"),
        array("Sara", "Gandhi", "Female", "Comment1", "img2"),
        array("Jack","Smith", "Male", "Comment3", "img3"),
        array("Ann", "Miller", "Female", "Comment4","img4")
    );
    
    foreach($array as $row){
        echo '<div>';
        $i=0;
        do {
            echo $row[$i];
            $i++;
        }while($i<5);
        echo '<img>';
        echo '</div><br/>';
    }
    


    

    
    function getFirst(){
        $data = file_get_contents('temp.txt');
        $pieces = explode(',', $data);
        echo htmlspecialchars($pieces[0]);
    }
    
    function getLast(){
        $data = file_get_contents('temp.txt');
        $pieces = explode(',', $data);
        echo htmlspecialchars($pieces[1]);
    }
    
    function getComment(){
        $data = file_get_contents('temp.txt');
        echo htmlspecialchars($pieces[3]);
    }
    
    function getGender(){
        $data = file_get_contents('temp.txt');
        echo htmlspecialchars($pieces[2]);
    }
    
    function peoplePlacer(){
        $data = file_get_contents('temp.txt');
        echo htmlspecialchars($pieces[2]);
    }
?>