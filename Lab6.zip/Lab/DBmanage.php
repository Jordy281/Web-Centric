<?php
    
    $servername = "localhost";
    $username = "username";
    $password = "password";
try
{
    $conn = new PDO("mysql:host=$servername;", $username, $password);

    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    $sql="CREATE DATABASE students";
    //use exec() because no results are returned
    $conn->exec($sql);
    echo "Connected successfully";
    
    $sql = 'CREATE TABLE grade (
        id= VARCHAR(30) UNSIGNED PRIMARY KEY,
        FamilyName= VARCHAR(50) NOT NULL,
        FirstName= VARCHAR(50) NOT NULL,
        GPA = Float(6,4);
    )';
    $conn->exec($sql);
    //Begin the transaction of inserting multiple items into the database
    $conn->beginTransaction();
    //Item 1
    $conn->exec('INSERT INTO grade (id, FamilyName, FirstName, GPA) VALUES ('B123456','Stirling','Jordan',4.0)');
    $conn->exec('INSERT INTO grade (id, FamilyName, FirstName, GPA) VALUES ('B111111','a','a',3.0)');
    $conn->exec('INSERT INTO grade (id, FamilyName, FirstName, GPA) VALUES ('B222222','b','b',2.0)');
    $conn->exec('INSERT INTO grade (id, FamilyName, FirstName, GPA) VALUES ('B333333','d','c',1.0)');
    $conn->commit();
    
    $conn->exec('DELETE FROM 'grade' WHERE 'id'='B123456')
    
}
catch(PDOExceptionn $e)
{
    echo "Connection failed: " . $e->getMessage();
    
}
$conn = null;


?>